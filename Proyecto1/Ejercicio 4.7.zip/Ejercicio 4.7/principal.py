
import sys

from prompt_toolkit import prompt
from Ventana import *

class Principal(QtWidgets.QDialog,Ui_Dialog):
	def __init__(self):
		QtWidgets.QDialog.__init__(self)
		self.setupUi(self)
		self.cp=0
		self.cn=0
		self.pushButton_2.clicked.connect(self.contar)
	def contar(self):
		cantidadNumeros=int(self.Numeros.text())
		ca=int(self.CA.text())
		if cantidadNumeros>=1:
			if ca>0:
				self.cp=self.cp+1
				self.Numeros.setText(str(cantidadNumeros-1))
			else:
				self.cn=self.cn+1
				self.Numeros.setText(str(cantidadNumeros-1))
		else:
			self.pushButton_2.hide()
				
		
		self.label_5.setText(str(self.cp))
		self.label_6.setText(str(self.cn))
if __name__=="__main__":
	app=QtWidgets.QApplication(sys.argv)
	dialogo=Principal()
	dialogo.show()
	sys.exit(app.exec_())
